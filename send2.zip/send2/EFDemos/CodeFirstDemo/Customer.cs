﻿using System;

namespace CodeFirstDemo
{
    class Customer
    { 
         public int CustomerId{get; set;}
        public string City{get; set;}
        public string Name { get; set; }
       

    }
    

}
